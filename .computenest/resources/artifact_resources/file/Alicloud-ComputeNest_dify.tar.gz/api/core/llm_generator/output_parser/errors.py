class OutputParserException(Exception):
    pass
